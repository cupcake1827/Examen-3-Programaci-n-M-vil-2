﻿
namespace PM2E307 {
    public partial class MainPage : ContentPage {


        public MainPage() {
            InitializeComponent();
        }



    

    }

}
