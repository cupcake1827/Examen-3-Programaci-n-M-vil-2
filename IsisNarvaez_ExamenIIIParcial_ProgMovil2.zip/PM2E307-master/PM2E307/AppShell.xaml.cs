﻿namespace PM2E307 {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
